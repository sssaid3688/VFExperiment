# HARDSWISH operator test

import os
import sys

import pytest  # noqa: E402
import torch  # noqa: E402
import triton  # noqa: E402, F401

import flag_gems  # noqa: E402
from flag_gems.experimental_ops.hardswish import (  # noqa: E402
    hardswish as gems_hardswish,
)
from flag_gems.experimental_ops.hardswish import (  # noqa: E402
    hardswish_out as gems_hardswish_out,
)

# Add parent directory to path to import flag_gems
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))
try:
    from tests.accuracy_utils import TO_CPU, gems_assert_close
except ImportError:
    # Fallback values when running outside pytest
    TO_CPU = False  # fallback

    def gems_assert_close(res, ref, dtype, **kwargs):
        # Simple fallback comparison
        torch.testing.assert_close(res, ref, **kwargs)


def to_reference(inp, upcast=False):
    if inp is None:
        return None
    if TO_CPU:
        ref_inp = inp.to("cpu")
    else:
        ref_inp = inp.clone()
    if upcast:
        if ref_inp.is_complex():
            ref_inp = ref_inp.to(torch.complex128)
        else:
            ref_inp = ref_inp.to(torch.float64)
    return ref_inp


@pytest.mark.hardswish
@pytest.mark.parametrize("shape", [(2, 3), (128, 256), (1024, 1024)])
@pytest.mark.parametrize("dtype", [torch.float32, torch.float16, torch.bfloat16])
def test_hardswish_tensor(shape, dtype):
    x = torch.randn(shape, device=flag_gems.device, dtype=dtype)
    ref_x = to_reference(x)
    ref_out = torch.ops.aten.hardswish(ref_x)

    with flag_gems.use_gems():
        act_out = gems_hardswish(x.clone())

    gems_assert_close(act_out, ref_out, dtype=dtype)


@pytest.mark.hardswish
@pytest.mark.parametrize("shape", [(2, 3), (128, 256), (1024, 1024)])
@pytest.mark.parametrize("dtype", [torch.float32, torch.float16, torch.bfloat16])
def test_hardswish_out(shape, dtype):
    x = torch.randn(shape, device=flag_gems.device, dtype=dtype)
    ref_x = to_reference(x)
    act_x = x.clone()

    ref_out = torch.empty_like(ref_x)
    act_out = torch.empty_like(act_x)

    ref_ret = torch.ops.aten.hardswish.out(ref_x, out=ref_out)  # noqa: F841
    with flag_gems.use_gems():
        act_ret = gems_hardswish_out(act_x, act_out)

    gems_assert_close(act_out, ref_out, dtype=dtype)
    gems_assert_close(act_ret, ref_out, dtype=dtype)
