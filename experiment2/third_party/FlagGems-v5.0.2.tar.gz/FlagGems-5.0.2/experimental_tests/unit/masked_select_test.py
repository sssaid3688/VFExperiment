# MASKED_SELECT operator test

import os
import sys

import pytest  # noqa: E402
import torch  # noqa: E402
import triton  # noqa: E402, F401

import flag_gems  # noqa: E402
from flag_gems.experimental_ops.masked_select import (  # noqa: E402
    masked_select as gems_masked_select,
)
from flag_gems.experimental_ops.masked_select import (  # noqa: E402
    masked_select_out as gems_masked_select_out,
)

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

# Add parent directory to path to import flag_gems
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))
try:
    from tests.accuracy_utils import TO_CPU, gems_assert_close
except ImportError:
    # Fallback values when running outside pytest
    TO_CPU = False  # fallback

    def gems_assert_close(res, ref, dtype, **kwargs):
        # Simple fallback comparison
        torch.testing.assert_close(res, ref, **kwargs)


def to_reference(inp, upcast=False):
    if inp is None:
        return None
    if TO_CPU:
        ref_inp = inp.to("cpu")
    else:
        ref_inp = inp.clone()
    if upcast:
        if ref_inp.is_complex():
            ref_inp = ref_inp.to(torch.complex128)
        else:
            ref_inp = ref_inp.to(torch.float64)
    return ref_inp


@pytest.mark.masked_select
@pytest.mark.parametrize("shape", [(2, 3), (128, 256), (512, 512)])
@pytest.mark.parametrize("dtype", [torch.float32, torch.float16, torch.bfloat16])
def test_masked_select_tensor(shape, dtype):
    x = torch.randn(shape, dtype=dtype, device=flag_gems.device)
    mask = torch.rand(shape, device=flag_gems.device) > 0.5

    ref_x = to_reference(x)
    ref_mask = to_reference(mask)

    ref_out = torch.ops.aten.masked_select(ref_x, ref_mask)

    with flag_gems.use_gems():
        act_out = gems_masked_select(x, mask)

    gems_assert_close(act_out, ref_out, dtype=dtype)


@pytest.mark.masked_select
@pytest.mark.parametrize("shape", [(2, 3), (128, 256), (512, 512)])
@pytest.mark.parametrize("dtype", [torch.float32, torch.float16, torch.bfloat16])
def test_masked_select_out(shape, dtype):
    x = torch.randn(shape, dtype=dtype, device=flag_gems.device)
    mask = torch.rand(shape, device=flag_gems.device) > 0.5

    ref_x = to_reference(x)
    ref_mask = to_reference(mask)

    ref_n = int(ref_mask.sum().item())
    ref_out_buf = torch.empty((ref_n,), dtype=dtype, device=ref_x.device)
    ref_out = torch.ops.aten.masked_select.out(ref_x, ref_mask, out=ref_out_buf)

    with flag_gems.use_gems():
        act_n = int(mask.sum().item())
        act_out_buf = torch.empty((act_n,), dtype=dtype, device=flag_gems.device)
        act_out = gems_masked_select_out(x, mask, act_out_buf)

    gems_assert_close(act_out, ref_out, dtype=dtype)
