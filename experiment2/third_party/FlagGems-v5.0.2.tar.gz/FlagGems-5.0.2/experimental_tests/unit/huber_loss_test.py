# HUBER_LOSS operator test

import os
import sys

import pytest  # noqa: E402
import torch  # noqa: E402
import triton  # noqa: E402, F401

import flag_gems  # noqa: E402
from flag_gems.experimental_ops.huber_loss import (  # noqa: E402
    huber_loss as gems_huber_loss,
)
from flag_gems.experimental_ops.huber_loss import (  # noqa: E402
    huber_loss_out as gems_huber_loss_out,
)

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

# Add parent directory to path to import flag_gems
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))
try:
    from tests.accuracy_utils import TO_CPU, gems_assert_close
except ImportError:
    # Fallback values when running outside pytest
    TO_CPU = False  # fallback

    def gems_assert_close(res, ref, dtype, **kwargs):
        # Simple fallback comparison
        torch.testing.assert_close(res, ref, **kwargs)


def to_reference(inp, upcast=False):
    if inp is None:
        return None
    if TO_CPU:
        ref_inp = inp.to("cpu")
    else:
        ref_inp = inp.clone()
    if upcast:
        if ref_inp.is_complex():
            ref_inp = ref_inp.to(torch.complex128)
        else:
            ref_inp = ref_inp.to(torch.float64)
    return ref_inp


@pytest.mark.huber_loss
@pytest.mark.parametrize("shape", [(2, 3), (128, 256), (512, 512)])
@pytest.mark.parametrize("dtype", [torch.float32, torch.float16, torch.bfloat16])
@pytest.mark.parametrize("reduction", [0, 1, 2])
@pytest.mark.parametrize("delta", [0.5, 1.0, 2.0])
def test_huber_loss_tensor(shape, dtype, reduction, delta):
    self_tensor = torch.randn(shape, dtype=dtype, device=flag_gems.device)
    target_tensor = torch.randn(shape, dtype=dtype, device=flag_gems.device)

    ref_self = to_reference(self_tensor)
    ref_target = to_reference(target_tensor)
    ref_out = torch.ops.aten.huber_loss(ref_self, ref_target, reduction, float(delta))

    with flag_gems.use_gems():
        act_self = self_tensor.clone()
        act_target = target_tensor.clone()
        act_out = gems_huber_loss(act_self, act_target, reduction, float(delta))

    gems_assert_close(act_out, ref_out, dtype=dtype)


@pytest.mark.huber_loss
@pytest.mark.parametrize("shape", [(2, 3), (128, 256), (512, 512)])
@pytest.mark.parametrize("dtype", [torch.float32, torch.float16, torch.bfloat16])
@pytest.mark.parametrize("reduction", [0, 1, 2])
@pytest.mark.parametrize("delta", [0.5, 1.0, 2.0])
def test_huber_loss_out(shape, dtype, reduction, delta):
    self_tensor = torch.randn(shape, dtype=dtype, device=flag_gems.device)
    target_tensor = torch.randn(shape, dtype=dtype, device=flag_gems.device)

    if reduction == 0:
        out_shape = shape
    else:
        out_shape = ()

    ref_self = to_reference(self_tensor)
    ref_target = to_reference(target_tensor)
    ref_out = torch.empty(out_shape, dtype=dtype, device=ref_self.device)
    torch.ops.aten.huber_loss.out(
        ref_self, ref_target, reduction, float(delta), out=ref_out
    )

    with flag_gems.use_gems():
        act_self = self_tensor.clone()
        act_target = target_tensor.clone()
        act_out = torch.empty(out_shape, dtype=dtype, device=flag_gems.device)
        gems_huber_loss_out(act_self, act_target, reduction, float(delta), act_out)

    gems_assert_close(act_out, ref_out, dtype=dtype)
