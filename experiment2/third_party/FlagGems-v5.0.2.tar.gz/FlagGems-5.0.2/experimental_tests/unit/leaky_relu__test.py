# LEAKY_RELU_ operator test

import os
import sys

import pytest  # noqa: E402
import torch  # noqa: E402
import triton  # noqa: E402, F401

import flag_gems  # noqa: E402
from flag_gems.experimental_ops.leaky_relu_ import (  # noqa: E402
    leaky_relu_ as gems_leaky_relu_,
)

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

# Add parent directory to path to import flag_gems
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))
try:
    from tests.accuracy_utils import TO_CPU, gems_assert_close
except ImportError:
    # Fallback values when running outside pytest
    TO_CPU = False  # fallback

    def gems_assert_close(res, ref, dtype, **kwargs):
        # Simple fallback comparison
        torch.testing.assert_close(res, ref, **kwargs)


def to_reference(inp, upcast=False):
    if inp is None:
        return None
    if TO_CPU:
        ref_inp = inp.to("cpu")
    else:
        ref_inp = inp.clone()
    if upcast:
        if ref_inp.is_complex():
            ref_inp = ref_inp.to(torch.complex128)
        else:
            ref_inp = ref_inp.to(torch.float64)
    return ref_inp


@pytest.mark.leaky_relu_
@pytest.mark.parametrize("shape", [(2, 3), (128, 256), (512, 512)])
@pytest.mark.parametrize("dtype", [torch.float32, torch.float16, torch.bfloat16])
def test_leaky_relu__tensor_default(shape, dtype):
    x = torch.randn(shape, dtype=dtype, device=flag_gems.device)
    ref_x = to_reference(x)
    act_x = x.clone()

    ref_out = torch.ops.aten.leaky_relu_(ref_x)

    with flag_gems.use_gems():
        act_out = gems_leaky_relu_(act_x)

    gems_assert_close(act_out, ref_out, dtype=dtype)


@pytest.mark.leaky_relu_
@pytest.mark.parametrize("shape", [(2, 3), (128, 256), (512, 512)])
@pytest.mark.parametrize("dtype", [torch.float32, torch.float16, torch.bfloat16])
@pytest.mark.parametrize("negative_slope", [0.0, 0.01, 0.2, 1.5])
def test_leaky_relu__tensor_with_slope(shape, dtype, negative_slope):
    x = torch.randn(shape, dtype=dtype, device=flag_gems.device)
    ref_x = to_reference(x)
    act_x = x.clone()

    ref_out = torch.ops.aten.leaky_relu_(ref_x, negative_slope)

    with flag_gems.use_gems():
        act_out = gems_leaky_relu_(act_x, negative_slope)

    gems_assert_close(act_out, ref_out, dtype=dtype)
