# SOFTPLUS operator test

import os
import sys

import pytest
import torch

import flag_gems
from flag_gems.experimental_ops.softplus import softplus as gems_softplus
from flag_gems.experimental_ops.softplus import softplus_out as gems_softplus_out

# Add parent directory to path to import flag_gems
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))
try:
    from tests.accuracy_utils import TO_CPU, gems_assert_close
except ImportError:
    # Fallback values when running outside pytest
    TO_CPU = False  # fallback

    def gems_assert_close(res, ref, dtype, **kwargs):
        # Simple fallback comparison
        torch.testing.assert_close(res, ref, **kwargs)


def to_reference(inp, upcast=False):
    if inp is None:
        return None
    if TO_CPU:
        ref_inp = inp.to("cpu")
    else:
        ref_inp = inp.clone()
    if upcast:
        if ref_inp.is_complex():
            ref_inp = ref_inp.to(torch.complex128)
        else:
            ref_inp = ref_inp.to(torch.float64)
    return ref_inp


@pytest.mark.softplus
@pytest.mark.parametrize("shape", [(2, 3), (128, 256), (512, 512)])
@pytest.mark.parametrize("dtype", [torch.float32, torch.float16, torch.bfloat16])
@pytest.mark.parametrize("beta", [1.0, 2.0])
@pytest.mark.parametrize("threshold", [20.0, 10.0])
def test_softplus_tensor(shape, dtype, beta, threshold):
    input_tensor = torch.randn(shape, dtype=dtype, device=flag_gems.device)

    ref_input = to_reference(input_tensor)

    ref_out = torch.ops.aten.softplus(ref_input, beta, threshold)

    with flag_gems.use_gems():
        act_out = gems_softplus(input_tensor, beta, threshold)

    gems_assert_close(act_out, ref_out, dtype=dtype)


@pytest.mark.softplus
@pytest.mark.parametrize("shape", [(2, 3), (128, 256), (512, 512)])
@pytest.mark.parametrize("dtype", [torch.float32, torch.float16, torch.bfloat16])
@pytest.mark.parametrize("beta", [1.0, 2.0])
@pytest.mark.parametrize("threshold", [20.0, 10.0])
def test_softplus_out(shape, dtype, beta, threshold):
    input_tensor = torch.randn(shape, dtype=dtype, device=flag_gems.device)
    out_act = torch.empty(shape, dtype=dtype, device=flag_gems.device)

    ref_input = to_reference(input_tensor)
    out_ref = torch.empty(shape, dtype=dtype, device=ref_input.device)

    ref_out = torch.ops.aten.softplus.out(ref_input, beta, threshold, out=out_ref)

    with flag_gems.use_gems():
        act_out = gems_softplus_out(input_tensor, beta, threshold, out_act)

    gems_assert_close(act_out, ref_out, dtype=dtype)
