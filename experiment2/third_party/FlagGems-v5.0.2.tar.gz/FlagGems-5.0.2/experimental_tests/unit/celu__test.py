# CELU_ operator test

import os
import sys

import pytest
import torch

import flag_gems
from flag_gems.experimental_ops.celu_ import celu_ as gems_celu_

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

# Add parent directory to path to import flag_gems
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))
try:
    from tests.accuracy_utils import TO_CPU, gems_assert_close
except ImportError:
    # Fallback values when running outside pytest
    TO_CPU = False  # fallback

    def gems_assert_close(res, ref, dtype, **kwargs):
        # Simple fallback comparison
        torch.testing.assert_close(res, ref, **kwargs)


def to_reference(inp, upcast=False):
    if inp is None:
        return None
    if TO_CPU:
        ref_inp = inp.to("cpu")
    else:
        ref_inp = inp.clone()
    if upcast:
        if ref_inp.is_complex():
            ref_inp = ref_inp.to(torch.complex128)
        else:
            ref_inp = ref_inp.to(torch.float64)
    return ref_inp


@pytest.mark.celu_
@pytest.mark.parametrize("shape", [(2, 3), (128, 256), (1024, 1024)])
@pytest.mark.parametrize("dtype", [torch.float32, torch.float16, torch.bfloat16])
def test_celu__default_alpha(shape, dtype):
    inp = torch.randn(shape, dtype=dtype, device=flag_gems.device)
    inp_ref = to_reference(inp)
    inp_act = inp.clone()

    ref_out = torch.ops.aten.celu_(inp_ref)

    with flag_gems.use_gems():
        act_out = gems_celu_(inp_act)

    gems_assert_close(act_out, ref_out, dtype=dtype)


@pytest.mark.celu_
@pytest.mark.parametrize("shape", [(2, 3), (128, 256), (1024, 1024)])
@pytest.mark.parametrize("dtype", [torch.float32, torch.float16, torch.bfloat16])
@pytest.mark.parametrize("alpha", [0.5, 1.0, 2.0])
def test_celu__alpha(shape, dtype, alpha):
    inp = torch.randn(shape, dtype=dtype, device=flag_gems.device)
    inp_ref = to_reference(inp)
    inp_act = inp.clone()

    ref_out = torch.ops.aten.celu_(inp_ref, alpha)

    with flag_gems.use_gems():
        act_out = gems_celu_(inp_act, alpha)

    gems_assert_close(act_out, ref_out, dtype=dtype)
