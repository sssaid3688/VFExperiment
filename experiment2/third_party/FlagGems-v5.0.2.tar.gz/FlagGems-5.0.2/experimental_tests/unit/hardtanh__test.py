# HARDTANH_ operator test

import os
import sys

import pytest  # noqa: E402
import torch  # noqa: E402
import triton  # noqa: E402, F401

import flag_gems  # noqa: E402
from flag_gems.experimental_ops.hardtanh_ import (  # noqa: E402
    hardtanh_ as gems_hardtanh_,
)

# Add parent directory to path to import flag_gems
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))
try:
    from tests.accuracy_utils import TO_CPU, gems_assert_close
except ImportError:
    # Fallback values when running outside pytest
    TO_CPU = False  # fallback

    def gems_assert_close(res, ref, dtype, **kwargs):
        # Simple fallback comparison
        torch.testing.assert_close(res, ref, **kwargs)


def to_reference(inp, upcast=False):
    if inp is None:
        return None
    if TO_CPU:
        ref_inp = inp.to("cpu")
    else:
        ref_inp = inp.clone()
    if upcast:
        if ref_inp.is_complex():
            ref_inp = ref_inp.to(torch.complex128)
        else:
            ref_inp = ref_inp.to(torch.float64)
    return ref_inp


@pytest.mark.hardtanh_
@pytest.mark.parametrize("shape", [(2, 3), (128, 256), (1024, 1024)])
@pytest.mark.parametrize("dtype", [torch.float32, torch.float16, torch.bfloat16])
def test_hardtanh__defaults(shape, dtype):
    x = torch.randn(shape, device=flag_gems.device, dtype=dtype) * 3.0
    ref_input = to_reference(x)
    act_input = x.clone()

    ref_out = torch.ops.aten.hardtanh_(ref_input)

    with flag_gems.use_gems():
        act_out = gems_hardtanh_(act_input)

    gems_assert_close(act_out, ref_out, dtype=dtype)


@pytest.mark.hardtanh_
@pytest.mark.parametrize("shape", [(2, 3), (128, 256), (1024, 1024)])
@pytest.mark.parametrize("dtype", [torch.float32, torch.float16, torch.bfloat16])
@pytest.mark.parametrize("min_max", [(-1.0, 1.0), (0.0, 1.0), (-0.5, 0.5), (0.0, 0.0)])
def test_hardtanh__minmax(shape, dtype, min_max):
    min_val, max_val = min_max
    x = torch.randn(shape, device=flag_gems.device, dtype=dtype) * 3.0
    ref_input = to_reference(x)
    act_input = x.clone()

    ref_out = torch.ops.aten.hardtanh_(ref_input, min_val, max_val)

    with flag_gems.use_gems():
        act_out = gems_hardtanh_(act_input, min_val, max_val)

    gems_assert_close(act_out, ref_out, dtype=dtype)
