import math
import os
import random
from typing import Any, List, Optional

import pytest
import torch
import triton

import flag_gems
from benchmark.attri_util import FLOAT_DTYPES

from .performance_utils import Benchmark, GenericBenchmark, SkipVersion, vendor_name


class AttentionBenchmark(GenericBenchmark):
    """
    benchmark for attention
    """

    def set_more_shapes(self):
        # self.shapes is a list of tuples, each containing three elements:
        # (batch, num_heads, seq_len, head_size).
        return None


#
# sparse_attention shape layout:
# (batch, seq_len, kv_len, topk, heads, dim)
#
SPARSE_ATTENTION_SHAPES = [
    (16, 1, 136, 136, 8, 512),
    (16, 1, 392, 385, 8, 512),
    (16, 1, 392, 386, 8, 512),
    (16, 1, 392, 387, 8, 512),
    (32, 1, 392, 388, 8, 512),
    (32, 1, 392, 389, 8, 512),
    (32, 1, 392, 390, 8, 512),
    (32, 1, 392, 391, 8, 512),
    (64, 1, 136, 136, 8, 512),
    (64, 1, 392, 385, 8, 512),
    (64, 1, 392, 388, 8, 512),
    (64, 1, 392, 389, 8, 512),
]


def torch_sparse_attention(q, kv, attn_sink, topk_idxs, softmax_scale):
    batch, seq_len, heads, dim = q.shape
    topk = topk_idxs.shape[-1]

    kv_expanded = kv[:, None, :, :].expand(batch, seq_len, -1, dim)
    idx_expanded = topk_idxs[:, :, :, None].expand(batch, seq_len, topk, dim).long()
    gathered_kv = torch.gather(kv_expanded, 2, idx_expanded)

    scores = (
        torch.einsum("bmhd,bmtd->bmht", q.float(), gathered_kv.float()) * softmax_scale
    )
    sink = attn_sink[None, None, :, None].expand(batch, seq_len, heads, 1)
    attn = torch.softmax(torch.cat([scores, sink], dim=-1), dim=-1)

    out = torch.einsum("bmht,bmtd->bmhd", attn[:, :, :, :-1], gathered_kv.float())
    return out.to(q.dtype)


class SparseAttentionBenchmark(Benchmark):
    def set_shapes(self, shape_file_path=None):
        self.shapes = SPARSE_ATTENTION_SHAPES[:]
        self.shape_desc = "B, M, KV_LEN, TOPK, H, D"

    def set_more_shapes(self):
        return None

    def get_input_iter(self, cur_dtype):
        for seed, (batch, seq_len, kv_len, topk, heads, dim) in enumerate(self.shapes):
            torch.manual_seed(2026 + seed)
            q = torch.randn(
                (batch, seq_len, heads, dim),
                dtype=cur_dtype,
                device=self.device,
            )
            kv = torch.randn(
                (batch, kv_len, dim),
                dtype=cur_dtype,
                device=self.device,
            )
            attn_sink = torch.zeros((heads,), dtype=torch.float32, device=self.device)
            topk_idxs = torch.randint(
                0,
                kv_len,
                (batch, seq_len, topk),
                dtype=torch.int32,
                device=self.device,
            )
            yield q, kv, attn_sink, topk_idxs, 1.0 / math.sqrt(dim)


def torch_flash_attention_forward(
    q, k, v, scale, is_causal, dropout_p=0.0, return_debug_mask=False, **extra_kwargs
):
    return torch.ops.aten._flash_attention_forward(
        q,
        k,
        v,
        None,
        None,
        q.shape[-3],
        k.shape[-3],
        dropout_p,
        is_causal,
        return_debug_mask,
        scale=scale,
        **extra_kwargs,
    )


def gems_flash_attention_forward(
    q, k, v, scale, is_causal, dropout_p=0.0, return_debug_mask=False, **extra_kwargs
):
    return flag_gems.ops.flash_attention_forward(
        q,
        k,
        v,
        None,
        None,
        q.shape[-3],
        k.shape[-3],
        dropout_p,
        is_causal,
        return_debug_mask,
        scale=scale,
        **extra_kwargs,
    )


def torch_flash_attention_supports_alibi(device: str) -> bool:
    if device == "cpu" or not torch.cuda.is_available():
        return False
    try:
        q = torch.randn((1, 16, 1, 64), device=device, dtype=torch.float16)
        k = torch.randn((1, 16, 1, 64), device=device, dtype=torch.float16)
        v = torch.randn((1, 16, 1, 64), device=device, dtype=torch.float16)
        scale = float(1.0 / math.sqrt(64))
        alibi_slopes = torch.ones((1, 1), device=device, dtype=torch.float32) * 0.3
        torch.ops.aten._flash_attention_forward(
            q,
            k,
            v,
            None,
            None,
            q.shape[-3],
            k.shape[-3],
            0.0,
            False,
            False,
            scale=scale,
            alibi_slopes=alibi_slopes,
        )
        return True
    except RuntimeError as e:
        if "does not support alibi" in str(e).lower():
            return False
        raise


class FlashAttentionForwardBenchmark(GenericBenchmark):
    def set_shapes(self, shape_file_path=None):
        self.shapes = []
        for head_size in (64, 128, 192, 256):
            for is_causal in (False, True):
                self.shapes.append(
                    (
                        4,
                        8,
                        8,
                        1024,
                        128,
                        head_size,
                        is_causal,
                        0.0,
                        False,
                        None,
                        None,
                        False,
                    )
                )
        for batch, num_head, q_seq_len, kv_seq_len in (
            (1, 1, 128, 2048),
            (4, 8, 17, 1030),
        ):
            for is_causal in (False, True):
                self.shapes.append(
                    (
                        batch,
                        num_head,
                        num_head,
                        q_seq_len,
                        kv_seq_len,
                        128,
                        is_causal,
                        0.0,
                        False,
                        None,
                        None,
                        False,
                    )
                )

        supports_alibi = torch_flash_attention_supports_alibi(self.device)
        if supports_alibi:
            # GQA + alibi cases
            for head_size in (128, 192):
                for is_causal in (False, True):
                    self.shapes.append(
                        (
                            4,
                            8,
                            2,
                            1024,
                            1024,
                            head_size,
                            is_causal,
                            0.0,
                            False,
                            None,
                            None,
                            True,
                        )
                    )
            for is_causal in (False, True):
                self.shapes.append(
                    (4, 4, 4, 1, 519, 128, is_causal, 0.0, False, None, None, True)
                )

        # Split-KV like cases (q_seq_len=1, num_head_k < num_head).
        for is_causal in (False, True):
            self.shapes.append(
                (1, 4, 1, 1, 1024, 128, is_causal, 0.0, False, None, None, False)
            )
            if supports_alibi:
                self.shapes.append(
                    (1, 4, 1, 1, 1024, 128, is_causal, 0.0, False, None, None, True)
                )

        # Sliding window attention.
        for batch, num_head, q_seq_len, kv_seq_len in (
            (1, 1, 128, 2048),
            (8, 32, 1024, 1024),
            (8, 32, 1024, 128),
            (8, 32, 17, 1030),
        ):
            for window_size_left, window_size_right in ((256, 0), (128, 128)):
                self.shapes.append(
                    (
                        batch,
                        num_head,
                        num_head,
                        q_seq_len,
                        kv_seq_len,
                        128,
                        False,
                        0.0,
                        False,
                        window_size_left,
                        window_size_right,
                        False,
                    )
                )
        self.shapes.append(
            (8, 32, 32, 1024, 1024, 192, False, 0.0, False, 256, 0, False)
        )

        for is_causal in (False, True):
            self.shapes.append(
                (1, 1, 1, 1024, 1024, 128, is_causal, 0.2, True, None, None, False)
            )

    def set_more_shapes(self):
        return None


def flash_attention_forward_input_fn(config, dtype, device):
    (
        batch,
        num_head,
        num_head_k,
        q_seq_len,
        kv_seq_len,
        head_size,
        is_causal,
        dropout_p,
        return_debug_mask,
        window_size_left,
        window_size_right,
        use_alibi,
    ) = config

    q = torch.empty(
        (batch, q_seq_len, num_head, head_size), device=device, dtype=dtype
    ).uniform_(-0.05, 0.05)
    k = torch.empty(
        (batch, kv_seq_len, num_head_k, head_size), device=device, dtype=dtype
    ).uniform_(-0.05, 0.05)
    v = torch.empty(
        (batch, kv_seq_len, num_head_k, head_size), device=device, dtype=dtype
    ).uniform_(-0.05, 0.05)
    scale = float(1.0 / math.sqrt(head_size))

    extra_kwargs = {}
    if window_size_left is not None or window_size_right is not None:
        extra_kwargs.update(
            {
                "window_size_left": window_size_left,
                "window_size_right": window_size_right,
            }
        )
    if use_alibi:
        extra_kwargs["alibi_slopes"] = (
            torch.ones(batch, num_head, device=device, dtype=torch.float32) * 0.3
        )

    yield q, k, v, scale, is_causal, dropout_p, return_debug_mask, extra_kwargs


@pytest.mark.skipif(
    SkipVersion("torch", "<2.4"),
    reason="Low Pytorch Version.",
)
@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA is not available")
@pytest.mark.skipif(flag_gems.device == "cpu", reason="Unsupported in CPU mode")
@pytest.mark.flash_attention_forward
def test_perf_flash_attention_forward():
    bench = FlashAttentionForwardBenchmark(
        op_name="flash_attention_forward",
        input_fn=flash_attention_forward_input_fn,
        torch_op=torch_flash_attention_forward,
        dtypes=[torch.float16, torch.bfloat16],
    )
    bench.set_gems(gems_flash_attention_forward)
    bench.run()


# @pytest.mark.skipif(vendor_name == "kunlunxin", reason="RESULT TODOFIX")
# @pytest.mark.skipif(vendor_name == "hygon", reason="RuntimeError")
@pytest.mark.scaled_dot_product_attention
@pytest.mark.parametrize("dropout_p", [0.0])
@pytest.mark.parametrize("is_causal", [True, False])
def test_perf_scaled_dot_product_attention(dropout_p, is_causal):
    if flag_gems.vendor_name == "hygon":
        os.environ["TRITON_HIP_USE_NEW_STREAM_PIPELINE"] = "0"

    def scaled_dot_product_attention_kwargs(shape, dtype, device):
        query = torch.randn(shape, device=device, dtype=dtype)
        key = torch.randn(shape, device=device, dtype=dtype)
        value = torch.randn(shape, device=device, dtype=dtype)
        yield query, key, value, None, dropout_p, is_causal

    def sdpa_flash(
        query, key, value, attn_mask=None, dropout_p=dropout_p, is_causal=is_causal
    ):
        from torch.nn.attention import SDPBackend, sdpa_kernel

        with sdpa_kernel(backends=[SDPBackend.FLASH_ATTENTION]):
            torch.nn.functional.scaled_dot_product_attention(
                query,
                key,
                value,
                attn_mask=attn_mask,
                dropout_p=dropout_p,
                is_causal=is_causal,
            )

    bench = AttentionBenchmark(
        op_name="scaled_dot_product_attention",
        input_fn=scaled_dot_product_attention_kwargs,
        # torch_op=torch.nn.functional.scaled_dot_product_attention,
        torch_op=sdpa_flash,
        dtypes=[
            torch.float16,
            torch.bfloat16,
        ],
    )
    bench.set_gems(flag_gems.scaled_dot_product_attention)
    bench.run()
    if flag_gems.vendor_name == "hygon":
        del os.environ["TRITON_HIP_USE_NEW_STREAM_PIPELINE"]


@pytest.mark.skipif(flag_gems.device == "cpu", reason="Unsupported in CPU mode")
@pytest.mark.sparse_attention
def test_perf_sparse_attention():
    bench = SparseAttentionBenchmark(
        op_name="sparse_attention",
        torch_op=torch_sparse_attention,
        dtypes=[torch.bfloat16],
    )
    bench.set_gems(flag_gems.sparse_attn_triton)
    bench.run()


class FlashMLABenchmark(GenericBenchmark):
    """
    benchmark for flash_mla
    """

    def set_more_shapes(self):
        # self.shapes is a list of tuples, each containing three elements:
        # (batch, num_heads, seq_len, head_size).
        return None


# @pytest.mark.skipif(vendor_name == "kunlunxin", reason="RESULT TODOFIX")
@pytest.mark.skipif(vendor_name == "hygon", reason="RuntimeError")
@pytest.mark.flash_mla
def test_perf_flash_mla():
    def flash_mla_kwargs(shape, dtype, device):
        seqlen = shape[0]
        b = 128
        s_q = 1
        h_q = 128
        h_kv = 1
        d = 576
        dv = 512
        causal = True
        block_size = 64
        cache_seqlens = torch.tensor(
            [seqlen + 2 * i for i in range(b)], dtype=torch.int32, device=device
        )
        max_seqlen = cache_seqlens.max().item()
        max_seqlen_pad = triton.cdiv(max_seqlen, 256) * 256

        q = torch.randn([b, s_q, h_q, d], dtype=dtype, device=device)
        block_table = torch.arange(
            b * max_seqlen_pad // block_size, dtype=torch.int32, device=device
        ).view(b, max_seqlen_pad // block_size)
        blocked_k = torch.randn(
            [block_table.numel(), block_size, h_kv, d], dtype=dtype, device=device
        )
        yield q, block_table, blocked_k, max_seqlen_pad, block_size, b, s_q, cache_seqlens, h_q, h_kv, d, dv, causal

    def scaled_dot_product_attention(query, key, value, h_q, h_kv, is_causal=False):
        query = query.float()
        key = key.float()
        value = value.float()
        key = key.repeat_interleave(h_q // h_kv, dim=0)
        value = value.repeat_interleave(h_q // h_kv, dim=0)
        attn_weight = query @ key.transpose(-2, -1) / math.sqrt(query.size(-1))
        if is_causal:
            s_q = query.shape[-2]
            s_k = key.shape[-2]
            attn_bias = torch.zeros(s_q, s_k, dtype=query.dtype, device=query.device)
            temp_mask = torch.ones(
                s_q, s_k, dtype=torch.bool, device=query.device
            ).tril(diagonal=s_k - s_q)
            attn_bias.masked_fill_(temp_mask.logical_not(), float("-inf"))
            attn_bias.to(query.dtype)
            attn_weight += attn_bias
        lse = attn_weight.logsumexp(dim=-1)
        attn_weight = torch.softmax(attn_weight, dim=-1, dtype=torch.float32)
        return attn_weight @ value, lse

    def ref_mla(
        q,
        block_table,
        blocked_k,
        max_seqlen_pad,
        block_size,
        b,
        s_q,
        cache_seqlens,
        h_q,
        h_kv,
        d,
        dv,
        causal,
    ):
        device = q.device
        blocked_v = blocked_k[..., :dv]
        out = torch.empty(b, s_q, h_q, dv, dtype=torch.float32, device=device)
        lse = torch.empty(b, h_q, s_q, dtype=torch.float32, device=device)
        for i in range(b):
            begin = i * max_seqlen_pad
            end = begin + cache_seqlens[i]
            O, LSE = scaled_dot_product_attention(
                q[i].transpose(0, 1),
                blocked_k.view(-1, h_kv, d)[begin:end].transpose(0, 1),
                blocked_v.view(-1, h_kv, dv)[begin:end].transpose(0, 1),
                h_q=h_q,
                h_kv=h_kv,
                is_causal=causal,
            )
            out[i] = O.transpose(0, 1)
            lse[i] = LSE
        return out, lse

    if flag_gems.vendor_name == "mthreads":
        os.environ["MUSA_ENABLE_SQMMA"] = "1"

    bench = FlashMLABenchmark(
        op_name="flash_mla",
        input_fn=flash_mla_kwargs,
        torch_op=ref_mla,
        dtypes=[
            torch.bfloat16,
        ],
    )
    bench.set_gems(flag_gems.flash_mla)
    bench.run()

    if flag_gems.vendor_name == "mthreads":
        del os.environ["MUSA_ENABLE_SQMMA"]


class FlashAttnVarlenBenchmark(Benchmark):
    """
    benchmark for flash_attn_varlen_func
    """

    def set_shapes(self, shape_file_path: Optional[List[Any]] = None):
        # Collecting from qwen/Qwen3-1.7B --random-input 512 --random-output 2048 --num-prompts 200 --request-rate inf
        # Format: (cu_seq_lens_q, seqused_k, num_heads, head_size, block_size, num_blocks, alibi, soft_cap)

        all_cu_seq_lens_q = [
            (
                0,
                512,
            ),
            (
                0,
                1,
                2,
                72,
            ),
            tuple(range(0, 45))
            + (
                105,
                121,
                137,
                153,
                169,
                185,
                201,
                217,
                233,
                249,
                265,
            ),
            tuple(range(0, 196))
            + (
                211,
                226,
                240,
                253,
                265,
            ),
        ]
        all_seqused_k = [
            (512,),
            (
                1,
                1,
                70,
            ),
            (515,) + (514,) * 20 + (513,) * 20 + (512,) * 14,
            (2333,)
            + (2331,) * 20
            + (2330,) * 20
            + (2329,) * 14
            + (2328,) * 18
            + (2327,) * 15
            + (2326,) * 17
            + (2325,) * 18
            + (2324,) * 21
            + (2323,) * 22
            + (2322,) * 24
            + (2321,) * 5
            + (
                2320,
                2319,
                2318,
                2317,
                2316,
            ),
        ]

        num_heads = 16
        num_heads_k = 8
        head_dim = 128
        block_size = 16
        num_blocks = 2000
        alibi = False
        soft_cap = None

        all_configs = [
            (
                cu_seq_lens_q,
                seqused_k,
                num_heads,
                num_heads_k,
                head_dim,
                block_size,
                num_blocks,
                alibi,
                soft_cap,
            )
            for cu_seq_lens_q, seqused_k in zip(all_cu_seq_lens_q, all_seqused_k)
        ]

        self.shapes = all_configs

    def get_input_iter(self, cur_dtype):
        for config in self.shapes:
            yield self.flash_attn_varlen_input_fn(config, cur_dtype, self.device)

    def flash_attn_varlen_input_fn(self, config, dtype, device):
        """Input function for flash attention varlen benchmark"""
        (
            cu_query_lens,
            seqused_k,
            num_query_heads,
            num_kv_heads,
            head_size,
            block_size,
            num_blocks,
            alibi,
            soft_cap,
        ) = config

        if alibi is True and soft_cap is not None:
            return

        num_seqs = len(cu_query_lens) - 1
        max_query_len = max(
            map(lambda x, y: x - y, cu_query_lens[1:], cu_query_lens[:-1])
        )
        max_kv_len = max(seqused_k)
        window_size = (-1, -1)
        scale = head_size**-0.5

        assert num_seqs == len(seqused_k)

        with torch.device(device):
            query = torch.randn(
                cu_query_lens[-1],
                num_query_heads,
                head_size,
                dtype=dtype,
                device=device,
            )
            out = torch.empty_like(query)
            key_cache = torch.randn(
                num_blocks,
                block_size,
                num_kv_heads,
                head_size,
                dtype=dtype,
                device=device,
            )
            value_cache = torch.randn_like(key_cache)
            cu_query_lens = torch.tensor(
                cu_query_lens, dtype=torch.int32, device=device
            )
            seqused_k = torch.tensor(seqused_k, dtype=torch.int32, device=device)

            max_num_blocks_per_seq = (max_kv_len + block_size - 1) // block_size
            block_tables = torch.randint(
                0,
                num_blocks,
                (num_seqs, max_num_blocks_per_seq),
                dtype=torch.int32,
                device=device,
            )

            causal = True

            if alibi:
                alibi_slopes = (
                    torch.ones(
                        num_seqs, num_query_heads, device=device, dtype=torch.float32
                    )
                    * 0.3
                )
            else:
                alibi_slopes = None

        return (
            query,
            key_cache,
            value_cache,
            max_query_len,
            cu_query_lens,
            max_kv_len,
            None,
            seqused_k,
            None,
            0.0,
            scale,
            causal,
            window_size,
            soft_cap if soft_cap is not None else 0,
            alibi_slopes,
            False,
            False,
            block_tables,
            False,
            out,
            None,
            None,
            None,
            None,
            {
                "s_aux": None,
                "num_splits": 0,
                "cp_world_size": 1,
                "cp_rank": 0,
                "cp_tot_seqused_k": None,
                "fa_version": 2,
            },
        )


def flash_attn_varlen_legacy(*args, **kwargs):
    """
    Compatibility wrapper for running old flash_attn_varlen_func.
    """
    (
        query,
        key_cache,
        value_cache,
        max_query_len,
        cu_query_lens,
        max_kv_len,
        _,
        seqused_k,
        _,
        dropout_p,
        scale,
        causal,
        window_size,
        soft_cap,
        alibi_slopes,
        deterministic,
        return_attn_probs,
        block_tables,
        _,
        out,
        *_,
    ) = args

    k_flat = key_cache.reshape(-1, key_cache.shape[2], key_cache.shape[3])
    v_flat = value_cache.reshape(-1, value_cache.shape[2], value_cache.shape[3])
    cu_seqlens_k = torch.cat(
        [
            torch.zeros(1, dtype=torch.int32, device=seqused_k.device),
            torch.cumsum(seqused_k, dim=0),
        ]
    ).to(torch.int32)

    from flash_attn import flash_attn_varlen_func

    result = flash_attn_varlen_func(
        query,  # q
        k_flat,  # k (flattened from key_cache)
        v_flat,  # v (flattened from value_cache)
        cu_query_lens,  # cu_seqlens_q
        cu_seqlens_k,  # cu_seqlens_k (constructed from seqused_k)
        max_query_len,  # max_seqlen_q
        max_kv_len,  # max_seqlen_k
        dropout_p,  # dropout_p
        scale,  # softmax_scale
        causal,  # causal
        tuple(window_size),  # window_size
        float(soft_cap),  # softcap
        alibi_slopes,  # alibi_slopes
        deterministic,  # deterministic
        return_attn_probs,  # return_attn_probs
        block_tables,  # block_table
        alibi_slopes is not None,  # use_alibi (derived from alibi_slopes)
        0,  # alibi_mode
        1,  # imp_mode
        out=out,  # out
        bias=None,  # bias
    )
    return result


@pytest.mark.skipif(
    SkipVersion("vllm", "<0.9"),
    reason="The version prior to 0.9 does not include the flash_attn_varlen_func API in vllm.",
)
@pytest.mark.skipif(
    SkipVersion("torch", "<2.7"),
    reason="The version prior to 2.7 is not compatible with VLLM.",
)
# @pytest.mark.skipif(vendor_name == "kunlunxin", reason="RESULT TODOFIX")
@pytest.mark.skipif(vendor_name == "hygon", reason="RuntimeError")
@pytest.mark.skipif(vendor_name == "mthreads", reason="Torch < 2.7")
@pytest.mark.skipif(flag_gems.vendor_name == "cambricon", reason="TypeError")
@pytest.mark.flash_attn_varlen_func
def test_perf_flash_attn_varlen_func():
    os.environ["VLLM_CONFIGURE_LOGGING"] = "0"
    if vendor_name == "iluvatar":
        # iluvatar does not have updated vllm_flash_attn, use conversion wrapper
        flash_attn_varlen_func = flash_attn_varlen_legacy
    else:
        from vllm.vllm_flash_attn.flash_attn_interface import flash_attn_varlen_func

    bench = FlashAttnVarlenBenchmark(
        op_name="flash_attn_varlen_func",
        torch_op=flash_attn_varlen_func,
        dtypes=[torch.float16, torch.bfloat16],
    )
    bench.set_gems(flag_gems.ops.flash_attn_varlen_func)
    bench.run()


class GetSchedulerMetadataBenchmark(GenericBenchmark):
    """
    benchmark for get_scheduler_metadata
    """

    def set_shapes(self, shape_file_path=None):
        self.shapes = [
            (8, 8, 1024, 16, 4, 128, 128),
            (32, 32, 512, 8, 8, 64, 64),
            (256, 256, 2048, 32, 32, 128, 128),
            (512, 512, 4096, 32, 8, 128, 128),
            (1024, 1024, 8192, 64, 16, 128, 128),
        ]

    def set_more_shapes(self):
        return None


@pytest.mark.get_scheduler_metadata
def test_perf_get_scheduler_metadata():
    try:
        os.environ["VLLM_CONFIGURE_LOGGING"] = "0"
        from vllm.vllm_flash_attn.flash_attn_interface import (
            get_scheduler_metadata as vllm_get_scheduler_metadata,
        )
    except ImportError:
        pytest.skip("vllm is not available, skipping performance test")

    def input_kwargs(shape, dtype, device):
        (
            batch_size,
            max_seqlen_q,
            max_seqlen_k,
            num_heads_q,
            num_heads_kv,
            headdim,
            headdim_v,
        ) = shape
        cache_seqlens = torch.randint(
            1, max_seqlen_k + 1, (batch_size,), dtype=torch.int32, device=device
        )

        yield (
            batch_size,
            max_seqlen_q,
            max_seqlen_k,
            num_heads_q,
            num_heads_kv,
            headdim,
            cache_seqlens,
            dtype,  # qkv_dtype
            headdim_v,  # headdim_v
            None,  # cu_seqlens_q
            None,  # cu_seqlens_k_new
            None,  # cache_leftpad
            None,  # page_size
            0,  # max_seqlen_k_new
            False,  # causal
            (-1, -1),  # window_size
            False,  # has_softcap
            0,  # num_splits
            None,  # pack_gqa
            0,  # sm_margin
        )

    def flaggems_wrapper(
        batch_size,
        max_seqlen_q,
        max_seqlen_k,
        num_heads_q,
        num_heads_kv,
        headdim,
        cache_seqlens,
        qkv_dtype=torch.bfloat16,
        headdim_v=None,
        cu_seqlens_q=None,
        cu_seqlens_k_new=None,
        cache_leftpad=None,
        page_size=None,
        max_seqlen_k_new=0,
        causal=False,
        window_size=(-1, -1),
        has_softcap=False,
        num_splits=0,
        pack_gqa=None,
        sm_margin=0,
    ):
        return flag_gems.ops.get_scheduler_metadata(
            batch_size=batch_size,
            max_seqlen_q=max_seqlen_q,
            max_seqlen_k=max_seqlen_k,
            num_heads=num_heads_q,
            num_heads_k=num_heads_kv,
            headdim=headdim,
            headdim_v=headdim_v or headdim,
            qkv_dtype=qkv_dtype,
            seqused_k=cache_seqlens,
            cu_seqlens_q=cu_seqlens_q,
            cu_seqlens_k=None,
            cu_seqlens_k_new=cu_seqlens_k_new,
            seqused_q=None,
            leftpad_k=cache_leftpad,
            page_size=page_size,
            max_seqlen_k_new=max_seqlen_k_new,
            is_causal=causal,
            window_size_left=window_size[0],
            window_size_right=window_size[1],
            has_softcap=has_softcap,
            num_splits=num_splits,
            pack_gqa=pack_gqa,
            sm_margin=sm_margin,
        )

    bench = GetSchedulerMetadataBenchmark(
        op_name="get_scheduler_metadata",
        input_fn=input_kwargs,
        torch_op=vllm_get_scheduler_metadata,
        dtypes=[
            torch.float16,
            torch.bfloat16,
        ],
    )
    bench.set_gems(flaggems_wrapper)
    bench.run()


def torch_concat_and_cache_mla_ref(
    kv_c: torch.Tensor,
    k_pe: torch.Tensor,
    kv_cache: torch.Tensor,
    slot_mapping: torch.Tensor,
    kv_cache_dtype: str = "auto",
    scale: torch.Tensor | None = None,
) -> None:
    kv_lora_rank = kv_c.size(1)
    block_size = kv_cache.size(1)
    temp_cache = torch.zeros(kv_cache.shape, dtype=kv_c.dtype, device=kv_cache.device)

    for token_idx in range(slot_mapping.numel()):
        slot = slot_mapping[token_idx].item()
        block_id = slot // block_size
        block_offset = slot % block_size
        temp_cache[block_id, block_offset, :kv_lora_rank] = kv_c[token_idx]
        temp_cache[block_id, block_offset, kv_lora_rank:] = k_pe[token_idx]

    if kv_cache_dtype != "auto":
        scale_val = scale.item() if scale is not None else 1.0
        kv_cache.copy_(
            (temp_cache / scale_val).to(torch.float8_e4m3fn).view(torch.uint8)
        )
    else:
        kv_cache.copy_(temp_cache)


class ConcatAndCacheMLABenchmark(GenericBenchmark):
    """
    benchmark for concat_and_cache_mla
    """

    def set_more_shapes(self):
        return None


@pytest.mark.skipif(flag_gems.vendor_name == "hygon", reason="RuntimeError")
@pytest.mark.concat_and_cache_mla
def test_perf_concat_and_cache_mla():
    def input_kwargs(shape, dtype, device):
        (
            kv_lora_rank,
            qk_rope_head_dim,
            num_tokens,
            block_size,
            num_blocks,
        ) = shape
        total_slots = num_blocks * block_size
        slot_mapping_lst = random.sample(range(total_slots), num_tokens)
        slot_mapping = torch.tensor(slot_mapping_lst, dtype=torch.long, device=device)

        kv_c = torch.randn(num_tokens, kv_lora_rank, dtype=dtype, device=device)
        k_pe = torch.randn(num_tokens, qk_rope_head_dim, dtype=dtype, device=device)
        entry_size = kv_lora_rank + qk_rope_head_dim

        scale = torch.tensor(0.1, dtype=torch.float32, device=device)

        kv_cache = torch.zeros(
            num_blocks,
            block_size,
            entry_size,
            dtype=dtype,
            device=device,
        )

        yield (
            kv_c,
            k_pe,
            kv_cache,
            slot_mapping,
            {"kv_cache_dtype": "auto", "scale": scale},
        )

    bench = ConcatAndCacheMLABenchmark(
        op_name="concat_and_cache_mla",
        input_fn=input_kwargs,
        torch_op=torch_concat_and_cache_mla_ref,
        dtypes=FLOAT_DTYPES,
    )
    bench.set_gems(flag_gems.concat_and_cache_mla)
    bench.run()


def torch_reshape_and_cache_flash_ref(
    key: Any,
    value: Any,
    key_cache: Any,
    value_cache: Any,
    slot_mapping: Any,
    kv_cache_dtype: Any = "auto",
    k_scale: Any = None,
    v_scale: Any = None,
):
    block_size = key_cache.size(1)
    num_tokens = slot_mapping.numel()
    for i in range(num_tokens):
        slot = slot_mapping[i].item()
        block_idx = slot // block_size
        block_offset = slot % block_size
        key_cache[block_idx, block_offset] = key[i]
        value_cache[block_idx, block_offset] = value[i]


class ReshapeAndCacheFlashBenchmark(GenericBenchmark):
    """
    benchmark for reshape_and_cache_flash
    """

    def set_more_shapes(self):
        return None


@pytest.mark.reshape_and_cache_flash
def test_perf_reshape_and_cache_flash():
    def input_kwargs(shape, dtype, device):
        (
            num_tokens,
            num_heads,
            head_size,
            block_size,
            num_blocks,
        ) = shape
        num_slots = block_size * num_blocks
        slot_mapping_lst = random.sample(range(num_slots), num_tokens)
        slot_mapping = torch.tensor(slot_mapping_lst, dtype=torch.long, device=device)
        qkv = torch.randn(
            num_tokens, 3, num_heads, head_size, dtype=dtype, device=device
        )
        _, key, value = qkv.unbind(dim=1)

        key_value_cache_shape = (num_blocks, 2, block_size, num_heads, head_size)
        scale = head_size**-0.5
        key_caches: list[torch.Tensor] = []
        value_caches: list[torch.Tensor] = []
        key_value_cache = torch.empty(
            size=key_value_cache_shape, dtype=dtype, device=device
        )
        key_value_cache.uniform_(-scale, scale)
        key_caches.append(key_value_cache[:, 0])
        value_caches.append(key_value_cache[:, 1])
        key_cache, value_cache = (
            key_caches[0].contiguous(),
            value_caches[0].contiguous(),
        )
        del key_caches
        del value_caches

        k_scale = (key.amax() / 64.0).to(torch.float32)
        v_scale = (value.amax() / 64.0).to(torch.float32)

        yield (
            key,
            value,
            key_cache,
            value_cache,
            slot_mapping,
            {
                "kv_cache_dtype": "auto",
                "k_scale": k_scale,
                "v_scale": v_scale,
            },
        )

    bench = ReshapeAndCacheFlashBenchmark(
        op_name="reshape_and_cache_flash",
        input_fn=input_kwargs,
        torch_op=torch_reshape_and_cache_flash_ref,
        dtypes=FLOAT_DTYPES,
    )
    bench.set_gems(flag_gems.reshape_and_cache_flash)
    bench.run()


def torch_reshape_and_cache_ref(
    key,  # [num_tokens, num_heads, head_size]
    value,  # [num_tokens, num_heads, head_size]
    key_cache,  # [num_blocks, num_heads, head_size/x, block_size, x]
    value_cache,  # [num_blocks, num_heads, head_size, block_size]
    slot_mapping,  # [num_tokens]
    kv_cache_dtype,
    k_scale,
    v_scale,
):
    num_tokens = slot_mapping.numel()
    block_size = key_cache.size(3)
    reshaped_key = key.reshape(num_tokens, *key_cache[0, :, :, 0, :].shape)
    for i in range(num_tokens):
        slot = slot_mapping[i].item()
        block_idx = slot // block_size
        block_offset = slot % block_size
        key_cache[block_idx, :, :, block_offset, :] = reshaped_key[i]
        value_cache[block_idx, :, :, block_offset] = value[i]


class ReshapeAndCacheBenchmark(GenericBenchmark):
    """
    benchmark for reshape_and_cache
    """

    def set_more_shapes(self):
        return None


@pytest.mark.reshape_and_cache
def test_perf_reshape_and_cache():
    def input_kwargs(shape, dtype, device):
        (
            num_tokens,
            num_heads,
            head_size,
            block_size,
            num_blocks,
        ) = shape
        num_slots = block_size * num_blocks
        slot_mapping_lst = random.sample(range(num_slots), num_tokens)
        slot_mapping = torch.tensor(slot_mapping_lst, dtype=torch.long, device=device)

        qkv = torch.randn(
            num_tokens, 3, num_heads, head_size, dtype=dtype, device=device
        )
        _, key, value = qkv.unbind(dim=1)

        scale = head_size**-0.5
        x = 16 // torch.tensor([], dtype=dtype).element_size()
        key_cache_shape = (num_blocks, num_heads, head_size // x, block_size, x)
        key_caches: list[torch.Tensor] = []
        key_cache = torch.empty(size=key_cache_shape, dtype=dtype, device=device)
        key_cache.uniform_(-scale, scale)
        key_caches.append(key_cache)
        value_cache_shape = (num_blocks, num_heads, head_size, block_size)
        value_caches: list[torch.Tensor] = []
        value_cache = torch.empty(size=value_cache_shape, dtype=dtype, device=device)
        value_cache.uniform_(-scale, scale)
        value_caches.append(value_cache)

        key_cache, value_cache = key_caches[0], value_caches[0]

        k_scale = (key.amax() / 64.0).to(torch.float32)
        v_scale = (value.amax() / 64.0).to(torch.float32)

        yield (
            key,
            value,
            key_cache,
            value_cache,
            slot_mapping,
            {
                "kv_cache_dtype": "auto",
                "k_scale": k_scale,
                "v_scale": v_scale,
            },
        )

    bench = ReshapeAndCacheBenchmark(
        op_name="reshape_and_cache",
        input_fn=input_kwargs,
        torch_op=torch_reshape_and_cache_ref,
        dtypes=FLOAT_DTYPES,
    )
    bench.set_gems(flag_gems.reshape_and_cache)
    bench.run()


class FlashAttnVarlenOptInitBenchmark(Benchmark):
    """
    benchmark for flash_attn_varlen_lse_func
    """

    def set_shapes(self, shape_file_path: Optional[List[Any]] = None):
        # Collecting from qwen/Qwen3-1.7B --random-input 512 --random-output 2048 --num-prompts 200 --request-rate inf
        # Format: (cu_seq_lens_q, seqused_k, num_heads, head_size, block_size, num_blocks, alibi, soft_cap)

        all_cu_seq_lens_q = [
            tuple(range(0, 45))
            + (
                105,
                121,
                137,
                153,
                169,
                185,
                201,
                217,
                233,
                249,
                265,
            ),
            tuple(range(0, 196))
            + (
                211,
                226,
                240,
                253,
                265,
            ),
            (
                0,
                1,
                2,
                72,
            ),
            (
                0,
                512,
            ),
        ]
        all_seqused_k = [
            (515,) + (514,) * 20 + (513,) * 20 + (512,) * 14,
            (2333,)
            + (2331,) * 20
            + (2330,) * 20
            + (2329,) * 14
            + (2328,) * 18
            + (2327,) * 15
            + (2326,) * 17
            + (2325,) * 18
            + (2324,) * 21
            + (2323,) * 22
            + (2322,) * 24
            + (2321,) * 5
            + (
                2320,
                2319,
                2318,
                2317,
                2316,
            ),
            (
                1,
                1,
                70,
            ),
            (512,),
        ]

        num_heads = 16
        num_heads_k = 8
        head_dim = 128
        block_size = 16
        num_blocks = 2000
        alibi = False
        soft_cap = None

        # cu_seq_lens_q = all_cu_seq_lens_q[1]
        # seqused_k = all_seqused_k[1]
        all_configs = [
            (
                cu_seq_lens_q,
                seqused_k,
                num_heads,
                num_heads_k,
                head_dim,
                block_size,
                num_blocks,
                alibi,
                soft_cap,
            )
            for cu_seq_lens_q, seqused_k in zip(all_cu_seq_lens_q, all_seqused_k)
        ]

        self.shapes = all_configs

    def get_input_iter(self, cur_dtype):
        for config in self.shapes:
            yield self.flash_attn_varlen_input_fn(config, cur_dtype, self.device)

    def flash_attn_varlen_input_fn(self, config, dtype, device):
        """Input function for flash attention varlen benchmark"""
        (
            cu_query_lens,
            seqused_k,
            num_query_heads,
            num_kv_heads,
            head_size,
            block_size,
            num_blocks,
            alibi,
            soft_cap,
        ) = config

        if alibi is True and soft_cap is not None:
            return

        num_seqs = len(cu_query_lens) - 1
        max_query_len = max(
            map(lambda x, y: x - y, cu_query_lens[1:], cu_query_lens[:-1])
        )
        max_kv_len = max(seqused_k)
        window_size = (-1, -1)
        scale = head_size**-0.5

        assert num_seqs == len(seqused_k)

        with torch.device(device):
            query = torch.randn(
                cu_query_lens[-1],
                num_query_heads,
                head_size,
                dtype=dtype,
                device=device,
            )
            out = torch.empty_like(query)
            lse = torch.empty(
                (num_query_heads, cu_query_lens[-1]), dtype=torch.float, device=device
            )
            # lse = None
            key_cache = torch.randn(
                num_blocks,
                block_size,
                num_kv_heads,
                head_size,
                dtype=dtype,
                device=device,
            )
            value_cache = torch.randn_like(key_cache)
            cu_query_lens = torch.tensor(
                cu_query_lens, dtype=torch.int32, device=device
            )
            seqused_k = torch.tensor(seqused_k, dtype=torch.int32, device=device)

            max_num_blocks_per_seq = (max_kv_len + block_size - 1) // block_size
            block_tables = torch.randint(
                0,
                num_blocks,
                (num_seqs, max_num_blocks_per_seq),
                dtype=torch.int32,
                device=device,
            )

            causal = True

            if alibi:
                alibi_slopes = (
                    torch.ones(
                        num_seqs, num_query_heads, device=device, dtype=torch.float32
                    )
                    * 0.3
                )
            else:
                alibi_slopes = None

        return (
            query,
            key_cache,
            value_cache,
            max_query_len,
            cu_query_lens,
            max_kv_len,
            None,
            seqused_k,
            None,
            0.0,
            scale,
            causal,
            window_size,
            soft_cap if soft_cap is not None else 0,
            alibi_slopes,
            False,
            False,
            block_tables,
            False,
            out,
            lse,
            None,
            None,
            None,
            None,
            None,
            0,
            1,
            0,
            None,
            2,
        )


def flash_attn_varlen_func_ref(*args, **kwargs):
    (
        q,
        k,
        v,
        max_seqlen_q,
        cu_seqlens_q,
        max_seqlen_k,
        cu_seqlens_k,  # only used for non-paged prefill
        seqused_k,
        q_v,
        dropout_p,
        softmax_scale,
        causal,
        window_size,
        softcap,  # 0.0 means deactivated
        alibi_slopes,
        deterministic,
        return_attn_probs,
        block_table,
        return_softmax_lse,
        out,
        lse,
        # Dummy FA3 arguments
        scheduler_metadata,
        q_descale,
        k_descale,
        v_descale,
        s_aux,
        num_splits,
        cp_world_size,
        cp_rank,
        cp_tot_seqused_k,
        fa_version,
    ) = args
    from vllm.vllm_flash_attn.flash_attn_interface import flash_attn_varlen_func

    result = flash_attn_varlen_func(
        q,
        k,
        v,
        max_seqlen_q,
        cu_seqlens_q,
        max_seqlen_k,
        cu_seqlens_k,  # only used for non-paged prefill
        seqused_k,
        q_v,
        dropout_p,
        softmax_scale,
        causal,
        window_size,
        softcap,  # 0.0 means deactivated
        alibi_slopes,
        deterministic,
        return_attn_probs,
        block_table,
        return_softmax_lse,
        out,
        # Dummy FA3 arguments
        scheduler_metadata,
        q_descale,
        k_descale,
        v_descale,
        fa_version,
    )
    return result


@pytest.mark.skipif(
    SkipVersion("vllm", "<0.9"),
    reason="The version prior to 0.9 does not include the flash_attn_varlen_func API in vllm.",
)
@pytest.mark.skipif(
    SkipVersion("torch", "<2.7"),
    reason="The version prior to 2.7 is not compatible with VLLM.",
)
@pytest.mark.skipif(vendor_name == "kunlunxin", reason="RESULT TODOFIX")
@pytest.mark.skipif(vendor_name == "hygon", reason="RuntimeError")
@pytest.mark.skipif(vendor_name == "mthreads", reason="Torch < 2.7")
@pytest.mark.skipif(flag_gems.vendor_name == "cambricon", reason="TypeError")
@pytest.mark.flash_attn_varlen_opt_init_func
def test_perf_flash_attn_varlen_opt_init_func():
    os.environ["VLLM_CONFIGURE_LOGGING"] = "0"
    bench = FlashAttnVarlenOptInitBenchmark(
        op_name="flash_attn_varlen_func",
        torch_op=flash_attn_varlen_func_ref,
        dtypes=[torch.float16, torch.bfloat16],
    )
    bench.set_gems(flag_gems.ops.flash_attn_varlen_opt_func)
    bench.run()
